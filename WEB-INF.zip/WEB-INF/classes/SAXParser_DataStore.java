import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;
import org.xml.sax.*;
import org.xml.sax.helpers.DefaultHandler;
import javax.xml.parsers.*;

public class SAXParser_DataStore extends DefaultHandler
{
	//String currentItem = null;
	
	//String xmlFileName = null;
	public static String HOME_DIR = System.getenv("CATALINA_HOME");
	//public final String PRODUCT_CATALOG_FILE = HOME_DIR + "\\webapps\\Assignment1\\ProductCatalog.xml";
	public static String PRODUCT_CATALOG_FILE = "C:\\apache-tomcat-7.0.34\\webapps\\Assignment5\\ProductCatalog.xml";

	Product product = null;
	List<String> accessories_list = null;
	String elementValue = null;

	static HashMap<String, List<Product>> products_map;// = new HashMap<>();
	static List<Product> tv_list;// = new ArrayList<>();
	static List<Product> soundSystem_list;// = new ArrayList<>();
	static List<Product> phone_list;// = new ArrayList<>();
	static List<Product> laptop_list;// = new ArrayList<>();
	static List<Product> voiceAssistant_list;// = new ArrayList<>();
	static List<Product> fitnessWatch_list;// = new ArrayList<>();
	static List<Product> smartWatch_list;// = new ArrayList<>();
	static List<Product> headphone_list;// = new ArrayList<>();
	static List<Product> basicPlan_list;// = new ArrayList<>();
	static List<Product> premiumPlan_list;// = new ArrayList<>();
	static List<Product> ultimatePlan_list;// = new ArrayList<>();
	static List<Product> accessory_catalog_list;// = new ArrayList<>();

	boolean nameFlag = false;
	boolean priceFlag = false;
	boolean imageFlag = false;
	boolean manufacturerFlag = false;
	boolean conditionFlag = false;
	boolean discountFlag = false;
	boolean accessoriesFlag = false;

	final static String KEY_TV = "tv";
	final static String KEY_SOUND_SYSTEM = "sound_system";
	final static String KEY_PHONE = "phone";
	final static String KEY_LAPTOP = "laptop";
	final static String KEY_VOICE_ASSISTANT = "voice_assistant";
	final static String KEY_FITNESS_WATCH = "fitness_watch";
	final static String KEY_SMART_WATCH = "smart_watch";
	final static String KEY_HEADPHONE = "headphone";
	final static String KEY_BASIC_PLAN = "basic_plan";
	final static String KEY_PREMIUM_PLAN = "premium_plan";
	final static String KEY_ULTIMATE_PLAN = "ultimate_plan";
	final static String KEY_ACCESSORIES_ITEMS = "accessory_item";

	SAXParser_DataStore()
	{
		products_map = new HashMap<>();	
		tv_list = new ArrayList<>();
		soundSystem_list = new ArrayList<>();
		phone_list = new ArrayList<>();
		laptop_list = new ArrayList<>();
		voiceAssistant_list = new ArrayList<>();
		fitnessWatch_list = new ArrayList<>();
		smartWatch_list = new ArrayList<>();
		headphone_list = new ArrayList<>();
		basicPlan_list = new ArrayList<>();
		premiumPlan_list = new ArrayList<>();
		ultimatePlan_list = new ArrayList<>();
		accessory_catalog_list = new ArrayList<>();

		//this.xmlFileName = xmlFileName;
		parseDocument();
	}
	private void parseDocument()
	{
		try{
			SAXParserFactory factory = SAXParserFactory.newInstance();
			SAXParser SAXParser = factory.newSAXParser();
			
			DefaultHandler handler = this;
			File f = new File(PRODUCT_CATALOG_FILE);
			SAXParser.parse(f, handler);
		}
		catch (ParserConfigurationException e) {
            System.out.println("ParserConfig error");
        } catch (SAXException e) {
            System.out.println("SAXException : xml not well formed");
        } catch (IOException e) {
            System.out.println("IO error");
        }
		catch(Exception e){}
	}

	//This method is called everytime the parser gets an open tag <
	//It identifies which tag is being opened
	@Override
	public void startElement(String uri, String localName, String elementName, Attributes attributes) throws SAXException
	{
		String item_id = null;
		if(elementName.equalsIgnoreCase("TV") ||
			elementName.equalsIgnoreCase("SoundSystem") ||
			elementName.equalsIgnoreCase("Phone") ||
			elementName.equalsIgnoreCase("Laptop") ||
			elementName.equalsIgnoreCase("VoiceAssistant") ||
			elementName.equalsIgnoreCase("FitnessWatch") ||
			elementName.equalsIgnoreCase("SmWatch") ||
			elementName.equalsIgnoreCase("Headphone") ||
			elementName.equalsIgnoreCase("Basic") ||
			elementName.equalsIgnoreCase("Premium") ||
			elementName.equalsIgnoreCase("Ultimate"))
		{
			item_id = attributes.getValue("id");
			product = new Product();
			product.setId(item_id);
			accessories_list = new ArrayList<>();
		}
		else if(elementName.equalsIgnoreCase("accessoryItem")){
			item_id = attributes.getValue("id");
			product = new Product();
			product.setId(item_id);
			//It will have no accessories
			accessories_list = null;
		}
		else if(elementName.equalsIgnoreCase("name"))
			nameFlag = true;
		else if(elementName.equalsIgnoreCase("price"))
			priceFlag = true;
		else if(elementName.equalsIgnoreCase("image"))
			imageFlag = true;
		else if(elementName.equalsIgnoreCase("manufacturer"))
			manufacturerFlag = true;
		else if(elementName.equalsIgnoreCase("condition"))
			conditionFlag = true;
		else if(elementName.equalsIgnoreCase("discount"))
			discountFlag = true;
		else if(elementName.equalsIgnoreCase("accessory"))
			accessoriesFlag = true;

		if(product != null)
		{

			if(elementName.equalsIgnoreCase("TV")){
				product.setType(KEY_TV);
			}

			else if(elementName.equalsIgnoreCase("SoundSystem")) {
				product.setType(KEY_SOUND_SYSTEM);
			}
			else if(elementName.equalsIgnoreCase("Phone")){
				product.setType(KEY_PHONE);
			} 
			else if(elementName.equalsIgnoreCase("Laptop")){
				product.setType(KEY_LAPTOP);
			} 
			else if(elementName.equalsIgnoreCase("VoiceAssistant")){
				product.setType(KEY_VOICE_ASSISTANT);
			} 
			else if(elementName.equalsIgnoreCase("FitnessWatch")){
				product.setType(KEY_FITNESS_WATCH);
			}
			else if(elementName.equalsIgnoreCase("SmWatch")){
				product.setType(KEY_SMART_WATCH);
			}
			else if(elementName.equalsIgnoreCase("Headphone")){
				product.setType(KEY_HEADPHONE);
			}
			else if(elementName.equalsIgnoreCase("Basic")){
				product.setType(KEY_BASIC_PLAN);
			}
			else if(elementName.equalsIgnoreCase("Premium")){
				product.setType(KEY_PREMIUM_PLAN);
			} 
			else if(elementName.equalsIgnoreCase("Ultimate")){
				product.setType(KEY_ULTIMATE_PLAN);
			}
			
		}

	}


	@Override
	public void endElement(String uri, String localName, String elementName) throws SAXException
	{
		if(elementName.equalsIgnoreCase("TV")) {
			tv_list.add(product);
			products_map.put(KEY_TV, tv_list);
		}
		else if(elementName.equalsIgnoreCase("SoundSystem")) {
			soundSystem_list.add(product);
			products_map.put(KEY_SOUND_SYSTEM, soundSystem_list);
		}
		else if(elementName.equalsIgnoreCase("Phone")) {
			phone_list.add(product);
			products_map.put(KEY_PHONE, phone_list);
		}
		else if(elementName.equalsIgnoreCase("Laptop")) {
			laptop_list.add(product);
			products_map.put(KEY_LAPTOP, laptop_list);
		}
		else if(elementName.equalsIgnoreCase("VoiceAssistant")) {
			voiceAssistant_list.add(product);
			products_map.put(KEY_VOICE_ASSISTANT, voiceAssistant_list);
		}
		else if(elementName.equalsIgnoreCase("FitnessWatch")) {
			fitnessWatch_list.add(product);
			products_map.put(KEY_FITNESS_WATCH, fitnessWatch_list);
		}
		else if(elementName.equalsIgnoreCase("SmWatch")) {
			smartWatch_list.add(product);
			products_map.put(KEY_SMART_WATCH, smartWatch_list);
		}
		else if(elementName.equalsIgnoreCase("Headphone")) {
			headphone_list.add(product);
			products_map.put(KEY_HEADPHONE, headphone_list);
		}
		else if(elementName.equalsIgnoreCase("Basic")) {
			basicPlan_list.add(product);
			products_map.put(KEY_BASIC_PLAN, basicPlan_list);
		}
		else if(elementName.equalsIgnoreCase("Premium")) {
			premiumPlan_list.add(product);
			products_map.put(KEY_PREMIUM_PLAN, premiumPlan_list);
		}
		else if(elementName.equalsIgnoreCase("Ultimate")) {
			ultimatePlan_list.add(product);
			products_map.put(KEY_ULTIMATE_PLAN, ultimatePlan_list);
		}
		else if(elementName.equalsIgnoreCase("accessoryItem")) {
			accessory_catalog_list.add(product);
			products_map.put(KEY_ACCESSORIES_ITEMS, accessory_catalog_list);
		}
		else if(elementName.equalsIgnoreCase("accessories")) {
			product.setAccessories(accessories_list);
			//accessories_list = null;
		}
		/*
		else if(elementName.equalsIgnoreCase("AccessoryCatalogItem")) {
			accessory_catalog_list.add(product);
			products_map.put(KEY_EXTERNAL_STORAGE, accessory_catalog_list);
		}
		*/

	}

	//print data stored between < and > tags
	@Override
    public void characters(char ch[], int start, int length) throws SAXException {
        elementValue = new String(ch, start, length);

        if(nameFlag) {
        	product.setName(elementValue);
        	nameFlag = false;
        }
        else if(priceFlag) {
        	product.setPrice(elementValue);
        	priceFlag = false;
        }
        else if(imageFlag) {
        	product.setImage(elementValue);
        	imageFlag = false;
        }
        else if(manufacturerFlag) {
        	product.setManufacturer(elementValue);
        	manufacturerFlag = false;
        }
        else if(conditionFlag) {
        	product.setCondition(elementValue);
        	conditionFlag = false;
        }
        else if(discountFlag) {
        	product.setDiscount(elementValue);
        	discountFlag = false;
        }
        if(accessoriesFlag) {
        	accessories_list.add(elementValue);
        	//product.setAccessories(accessories_list);
        	accessoriesFlag = false;
        }

    }

    public Map<String, List<Product>> getProductMap(){
    	return products_map;
    }
    
}

